# Phase 31b.6.2 install script
# Adds ReceiptExportController, amends submit() signature on the service,
# adds two new public methods (getStatus, getDownloadUrl) to the service,
# and wires the controller into ReportsModule.

$ErrorActionPreference = 'Stop'
$root = "C:\Users\Admin\OneDrive\Documents\ayende_bookkeeping_multitenant"
$utf8NoBom = [System.Text.UTF8Encoding]::new($false)

Write-Host ""
Write-Host "Phase 31b.6.2 install starting..."
Write-Host ""

# ============================================================================
# File 1: receipt-export.controller.ts (new)
# ============================================================================
$src1 = Join-Path $PSScriptRoot "files\apps\api\src\reports\controllers\receipt-export.controller.ts"
$dst1 = Join-Path $root "apps\api\src\reports\controllers\receipt-export.controller.ts"

if (-not (Test-Path -LiteralPath $src1)) {
    Write-Error "[FAIL] Source file not found: $src1"
    exit 1
}

Copy-Item -LiteralPath $src1 -Destination $dst1 -Force
Write-Host "[OK] Wrote $dst1"

# ============================================================================
# File 2: receipt-export.service.ts (5 anchor edits)
# ============================================================================
$path2 = Join-Path $root "apps\api\src\reports\services\receipt-export.service.ts"
$bytes2 = [System.IO.File]::ReadAllBytes($path2)
$content2 = [System.Text.Encoding]::UTF8.GetString($bytes2)

$useCRLF2 = $content2.Contains("`r`n")
$norm2 = $content2.Replace("`r`n", "`n")

# --- Anchor 2.1: add NotFoundException + ConflictException to imports ---
# Use here-strings to avoid backtick escaping. .Replace() needs LF-normalized
# content, so we explicitly normalize each here-string with .Replace before use.
$old2_1_raw = @'
import {
  Injectable,
  Logger,
  BadRequestException,
  HttpException,
  HttpStatus,
  Inject,
  forwardRef,
} from '@nestjs/common';
'@
$new2_1_raw = @'
import {
  Injectable,
  Logger,
  BadRequestException,
  HttpException,
  HttpStatus,
  Inject,
  forwardRef,
  NotFoundException,
  ConflictException,
} from '@nestjs/common';
'@
$old2_1 = $old2_1_raw.Replace("`r`n", "`n")
$new2_1 = $new2_1_raw.Replace("`r`n", "`n")

if (-not $norm2.Contains($old2_1)) {
    Write-Error "[FAIL] receipt-export.service.ts anchor 2.1 (imports) not found"
    exit 1
}
$count2_1 = ($norm2.Split([string[]]@($old2_1), [System.StringSplitOptions]::None).Length - 1)
if ($count2_1 -ne 1) {
    Write-Error "[FAIL] receipt-export.service.ts anchor 2.1 occurs $count2_1 times (expected 1)"
    exit 1
}
$norm2 = $norm2.Replace($old2_1, $new2_1)

# --- Anchor 2.2: import ReceiptExportStatusResponseDto ---
$old2_2 = "import { ReceiptExportSubmitDto } from '../dto/receipt-export.dto';"
$new2_2 = "import { ReceiptExportSubmitDto } from '../dto/receipt-export.dto';" + "`n" + "import { ReceiptExportStatusResponseDto } from '../dto/receipt-export-status.dto';"
if (-not $norm2.Contains($old2_2)) {
    Write-Error "[FAIL] receipt-export.service.ts anchor 2.2 (DTO import) not found"
    exit 1
}
$count2_2 = ($norm2.Split([string[]]@($old2_2), [System.StringSplitOptions]::None).Length - 1)
if ($count2_2 -ne 1) {
    Write-Error "[FAIL] receipt-export.service.ts anchor 2.2 occurs $count2_2 times (expected 1)"
    exit 1
}
$norm2 = $norm2.Replace($old2_2, $new2_2)

# --- Anchor 2.3: submit() signature - add userEmail param ---
$old2_3_raw = @'
  async submit(
    businessId: string,
    userId: string,
    dto: ReceiptExportSubmitDto,
  ): Promise<SubmitResult> {
'@
$new2_3_raw = @'
  async submit(
    businessId: string,
    userId: string,
    userEmail: string | null,
    dto: ReceiptExportSubmitDto,
  ): Promise<SubmitResult> {
'@
$old2_3 = $old2_3_raw.Replace("`r`n", "`n")
$new2_3 = $new2_3_raw.Replace("`r`n", "`n")

if (-not $norm2.Contains($old2_3)) {
    Write-Error "[FAIL] receipt-export.service.ts anchor 2.3 (submit signature) not found"
    exit 1
}
$count2_3 = ($norm2.Split([string[]]@($old2_3), [System.StringSplitOptions]::None).Length - 1)
if ($count2_3 -ne 1) {
    Write-Error "[FAIL] receipt-export.service.ts anchor 2.3 occurs $count2_3 times (expected 1)"
    exit 1
}
$norm2 = $norm2.Replace($old2_3, $new2_3)

# --- Anchor 2.4: persist user_email when creating the row ---
$old2_4_raw = @'
    const row = await this.jobRepo.save(
      this.jobRepo.create({
        business_id: businessId,
        user_id: userId,
        status: ReceiptExportStatus.QUEUED,
'@
$new2_4_raw = @'
    const row = await this.jobRepo.save(
      this.jobRepo.create({
        business_id: businessId,
        user_id: userId,
        user_email: userEmail,
        status: ReceiptExportStatus.QUEUED,
'@
$old2_4 = $old2_4_raw.Replace("`r`n", "`n")
$new2_4 = $new2_4_raw.Replace("`r`n", "`n")

if (-not $norm2.Contains($old2_4)) {
    Write-Error "[FAIL] receipt-export.service.ts anchor 2.4 (jobRepo.create) not found"
    exit 1
}
$count2_4 = ($norm2.Split([string[]]@($old2_4), [System.StringSplitOptions]::None).Length - 1)
if ($count2_4 -ne 1) {
    Write-Error "[FAIL] receipt-export.service.ts anchor 2.4 occurs $count2_4 times (expected 1)"
    exit 1
}
$norm2 = $norm2.Replace($old2_4, $new2_4)

# --- Anchor 2.5: insert two new public methods (getStatus, getDownloadUrl)
#                 immediately before the run() section header.
# Using a single-quoted here-string @'...'@ which performs NO interpolation -
# all backticks and dollar signs pass through verbatim.

$old2_5_raw = @'
  // ======================================================================
  // Public: run (Phase 31b.4 - real implementation)
'@
$old2_5 = $old2_5_raw.Replace("`r`n", "`n")

$newMethodsRaw = @'
  // ======================================================================
  // Public: getStatus (Phase 31b.6 - controller surface)
  // ======================================================================
  /**
   * Phase 31b.6 - Look up a job by id within the authed business and return
   * the whitelisted status shape (FR-31-6-10). 404 if not found / not owned.
   */
  async getStatus(
    businessId: string,
    jobId: string,
  ): Promise<ReceiptExportStatusResponseDto> {
    const job = await this.jobRepo.findOne({
      where: { id: jobId, business_id: businessId },
    });
    if (!job) {
      throw new NotFoundException(`Receipt export job ${jobId} not found`);
    }

    return {
      job_id: job.id,
      status: job.status,
      receipts_total: job.receipts_total,
      extracts_required: job.extracts_required,
      extracts_completed: job.extracts_completed,
      extracts_failed: job.extracts_failed,
      extracts_cap_exceeded: job.extracts_cap_exceeded,
      start_date: this.formatDateOnly(job.start_date),
      end_date: this.formatDateOnly(job.end_date),
      created_at: job.created_at.toISOString(),
      completed_at: job.completed_at ? job.completed_at.toISOString() : null,
      expires_at: job.expires_at ? job.expires_at.toISOString() : null,
      error_message: job.error_message,
    };
  }

  // ======================================================================
  // Public: getDownloadUrl (Phase 31b.6 - controller surface)
  // ======================================================================
  /**
   * Phase 31b.6 - Issue a 15-minute presigned S3 URL for the zip. The download
   * filename is derived from the job's date range
   * (tempo-receipts-YYYY-MM-DD-to-YYYY-MM-DD.zip).
   *
   * Errors:
   *   404 NotFound  - jobId not owned by business
   *   409 Conflict  - status !== complete (still running, queued, or failed)
   *   410 Gone      - past expires_at OR download_key missing
   */
  async getDownloadUrl(
    businessId: string,
    jobId: string,
  ): Promise<{ url: string; expires_in: number }> {
    const job = await this.jobRepo.findOne({
      where: { id: jobId, business_id: businessId },
    });
    if (!job) {
      throw new NotFoundException(`Receipt export job ${jobId} not found`);
    }

    if (job.status !== ReceiptExportStatus.COMPLETE) {
      throw new ConflictException(
        `Receipt export job is not ready for download (status: ${job.status})`,
      );
    }

    if (!job.download_key) {
      throw new HttpException(
        'Receipt export download is not available',
        HttpStatus.GONE,
      );
    }

    if (job.expires_at && job.expires_at.getTime() < Date.now()) {
      throw new HttpException(
        'Receipt export download has expired (zip retention is 7 days)',
        HttpStatus.GONE,
      );
    }

    const startDate = this.formatDateOnly(job.start_date);
    const endDate = this.formatDateOnly(job.end_date);
    const filename = `tempo-receipts-${startDate}-to-${endDate}.zip`;

    const bucket = process.env.AWS_S3_BUCKET ?? '';
    return this.documentsService.getPresignedDownloadByKey(
      bucket,
      job.download_key,
      filename,
    );
  }

  // ======================================================================
  // Public: run (Phase 31b.4 - real implementation)
'@
$newMethods = $newMethodsRaw.Replace("`r`n", "`n")

if (-not $norm2.Contains($old2_5)) {
    Write-Error "[FAIL] receipt-export.service.ts anchor 2.5 (run section header) not found"
    exit 1
}
$count2_5 = ($norm2.Split([string[]]@($old2_5), [System.StringSplitOptions]::None).Length - 1)
if ($count2_5 -ne 1) {
    Write-Error "[FAIL] receipt-export.service.ts anchor 2.5 occurs $count2_5 times (expected 1)"
    exit 1
}
$norm2 = $norm2.Replace($old2_5, $newMethods)

if ($useCRLF2) { $norm2 = $norm2.Replace("`n", "`r`n") }

[System.IO.File]::WriteAllText($path2, $norm2, $utf8NoBom)
Write-Host "[OK] Edited $path2 (5 anchors)"

# ============================================================================
# File 3: reports.module.ts (2 anchor edits - mount controller)
# ============================================================================
$path3 = Join-Path $root "apps\api\src\reports\reports.module.ts"
$bytes3 = [System.IO.File]::ReadAllBytes($path3)
$content3 = [System.Text.Encoding]::UTF8.GetString($bytes3)

$useCRLF3 = $content3.Contains("`r`n")
$norm3 = $content3.Replace("`r`n", "`n")

# Anchor 3.1: add ReceiptExportController import after HstController import.
$old3_1 = "import { HstController } from './controllers/hst.controller';"
$new3_1 = "import { HstController } from './controllers/hst.controller';" + "`n" + "import { ReceiptExportController } from './controllers/receipt-export.controller'; // Phase 31b.6"
if (-not $norm3.Contains($old3_1)) {
    Write-Error "[FAIL] reports.module.ts anchor 3.1 (HstController import) not found"
    exit 1
}
$count3_1 = ($norm3.Split([string[]]@($old3_1), [System.StringSplitOptions]::None).Length - 1)
if ($count3_1 -ne 1) {
    Write-Error "[FAIL] reports.module.ts anchor 3.1 occurs $count3_1 times (expected 1)"
    exit 1
}
$norm3 = $norm3.Replace($old3_1, $new3_1)

# Anchor 3.2: add controller to controllers array
$old3_2_raw = @'
    HstController,
  ],
'@
$new3_2_raw = @'
    HstController,
    ReceiptExportController, // Phase 31b.6
  ],
'@
$old3_2 = $old3_2_raw.Replace("`r`n", "`n")
$new3_2 = $new3_2_raw.Replace("`r`n", "`n")

if (-not $norm3.Contains($old3_2)) {
    Write-Error "[FAIL] reports.module.ts anchor 3.2 (controllers array) not found"
    exit 1
}
$count3_2 = ($norm3.Split([string[]]@($old3_2), [System.StringSplitOptions]::None).Length - 1)
if ($count3_2 -ne 1) {
    Write-Error "[FAIL] reports.module.ts anchor 3.2 occurs $count3_2 times (expected 1)"
    exit 1
}
$norm3 = $norm3.Replace($old3_2, $new3_2)

if ($useCRLF3) { $norm3 = $norm3.Replace("`n", "`r`n") }

[System.IO.File]::WriteAllText($path3, $norm3, $utf8NoBom)
Write-Host "[OK] Edited $path3 (2 anchors)"

Write-Host ""
Write-Host "Phase 31b.6.2 file install complete. Run tsc verification next."
Write-Host ""
