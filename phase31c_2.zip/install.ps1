# Phase 31c.2 install script
# Copies the new ReceiptExportModal client component into apps/web/src/components.

$ErrorActionPreference = 'Stop'
$root = "C:\Users\Admin\OneDrive\Documents\ayende_bookkeeping_multitenant"

Write-Host ""
Write-Host "Phase 31c.2 install starting..."
Write-Host ""

$src1 = Join-Path $PSScriptRoot "files\apps\web\src\components\receipt-export-modal.tsx"
$dstDir = Join-Path $root "apps\web\src\components"
$dst1 = Join-Path $dstDir "receipt-export-modal.tsx"

if (-not (Test-Path -LiteralPath $src1)) {
    Write-Error "[FAIL] Source file not found: $src1"
    exit 1
}

if (-not (Test-Path -LiteralPath $dstDir)) {
    Write-Error "[FAIL] Destination directory not found: $dstDir"
    exit 1
}

Copy-Item -LiteralPath $src1 -Destination $dst1 -Force
Write-Host "[OK] Wrote $dst1"

Write-Host ""
Write-Host "Phase 31c.2 file install complete. Run tsc verification next."
Write-Host ""
