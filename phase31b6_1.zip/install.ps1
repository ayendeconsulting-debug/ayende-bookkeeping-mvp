# Phase 31b.6.1 install script
# Adds user_email column to ReceiptExportJob entity + new status response DTO.
# No service or controller changes - schema-only deploy.

$ErrorActionPreference = 'Stop'
$root = "C:\Users\Admin\OneDrive\Documents\ayende_bookkeeping_multitenant"
$utf8NoBom = [System.Text.UTF8Encoding]::new($false)

Write-Host ""
Write-Host "Phase 31b.6.1 install starting..."
Write-Host ""

# ============================================================================
# File 1: receipt-export-status.dto.ts (new file)
# ============================================================================
$src1 = Join-Path $PSScriptRoot "files\apps\api\src\reports\dto\receipt-export-status.dto.ts"
$dst1 = Join-Path $root "apps\api\src\reports\dto\receipt-export-status.dto.ts"

if (-not (Test-Path -LiteralPath $src1)) {
    Write-Error "[FAIL] Source file not found: $src1"
    exit 1
}

Copy-Item -LiteralPath $src1 -Destination $dst1 -Force
Write-Host "[OK] Wrote $dst1"

# ============================================================================
# File 2: receipt-export-job.entity.ts (1 anchor edit - add user_email column)
# ============================================================================
$path2 = Join-Path $root "apps\api\src\entities\receipt-export-job.entity.ts"
$bytes2 = [System.IO.File]::ReadAllBytes($path2)
$content2 = [System.Text.Encoding]::UTF8.GetString($bytes2)

$useCRLF2 = $content2.Contains("`r`n")
$norm2 = $content2.Replace("`r`n", "`n")

# Anchor: insert user_email column after error_message column.
# Anchor text is the full error_message column block including its decorator
# and the blank line after it - this is unique in the file.
$old2 = "  @Column({ type: 'text', nullable: true })`n  error_message: string | null;`n`n  @CreateDateColumn"
$new2 = "  @Column({ type: 'text', nullable: true })`n  error_message: string | null;`n`n  // Phase 31b.6 - User email captured at submit time. Used by 31b.5 receipt`n  // export emails. Currently always null pending email-source decision`n  // (JWT enrichment vs Clerk SDK lookup vs subscription.customer_email`n  // fallback). 31b.5 will finalize the source.`n  @Column({ type: 'varchar', length: 255, nullable: true, default: null })`n  user_email: string | null;`n`n  @CreateDateColumn"

if (-not $norm2.Contains($old2)) {
    Write-Error "[FAIL] receipt-export-job.entity.ts anchor not found"
    exit 1
}

$count2 = ($norm2.Split([string[]]@($old2), [System.StringSplitOptions]::None).Length - 1)
if ($count2 -ne 1) {
    Write-Error "[FAIL] receipt-export-job.entity.ts anchor occurs $count2 times (expected 1)"
    exit 1
}

$norm2 = $norm2.Replace($old2, $new2)

if ($useCRLF2) { $norm2 = $norm2.Replace("`n", "`r`n") }

[System.IO.File]::WriteAllText($path2, $norm2, $utf8NoBom)
Write-Host "[OK] Edited $path2 (1 anchor)"

Write-Host ""
Write-Host "Phase 31b.6.1 file install complete. Run tsc verification next."
Write-Host ""
