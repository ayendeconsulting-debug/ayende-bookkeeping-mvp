# Phase 31c.1 install script
# Copies the new server actions file into the route group directory.
# Note: the destination path contains parentheses ("(app)"), which is a
# Next.js route group. PowerShell needs -LiteralPath for these paths.

$ErrorActionPreference = 'Stop'
$root = "C:\Users\Admin\OneDrive\Documents\ayende_bookkeeping_multitenant"

Write-Host ""
Write-Host "Phase 31c.1 install starting..."
Write-Host ""

# ============================================================================
# File 1: actions.ts (new) under (app)/reports/receipt-export/
# ============================================================================
$src1 = Join-Path $PSScriptRoot "files\apps\web\src\app\(app)\reports\receipt-export\actions.ts"
$dstDir = Join-Path $root "apps\web\src\app\(app)\reports\receipt-export"
$dst1 = Join-Path $dstDir "actions.ts"

if (-not (Test-Path -LiteralPath $src1)) {
    Write-Error "[FAIL] Source file not found: $src1"
    exit 1
}

# Create destination directory if it does not exist (route group dir is new).
if (-not (Test-Path -LiteralPath $dstDir)) {
    New-Item -ItemType Directory -Path $dstDir -Force | Out-Null
    Write-Host "[OK] Created directory $dstDir"
}

Copy-Item -LiteralPath $src1 -Destination $dst1 -Force
Write-Host "[OK] Wrote $dst1"

Write-Host ""
Write-Host "Phase 31c.1 file install complete. Run tsc verification next."
Write-Host ""
